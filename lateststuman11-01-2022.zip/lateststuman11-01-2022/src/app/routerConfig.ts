// routerConfig.ts

import { Routes } from '@angular/router';
import { DisplayComponent } from './display/display.component';
import {FormComponent} from './form/form.component';
import { DashboardComponent } from './dashboard/dashboard.component';

export const appRoutes: Routes = [
  { path: 'form',
    component: FormComponent
  },
  {
    path: 'display',
    component: DisplayComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  
];
