
import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';


import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

secData: any[] = ['A', 'B', 'C'];

  model: addressModel = {
    name: '',
    email: '',
    
    sec:[''],
    doj: ''
    
    
    
  };

  lststudent = Array(); //array
  oldstudent = Array();

  constructor() { }
  enrollform: any;

  ngOnInit(): void {

    this.oldstudent=JSON.parse(localStorage.getItem('student') || '{}');
    console.log(this.oldstudent);
   
    

  }

  onFormSubmit(){


    if(this.model){
      
      this.lststudent.push(this.model);
      localStorage.setItem('student',JSON.stringify(this.lststudent));
      alert("Your Data Is Sucessfully Submitted :)");
       console.log(this.model);
       this.model={
        
        name:'',
        email:'',
        sec:[''],
        doj:''
    
        
  
       }
       
   

    }
   

  }
}
export interface addressModel{
  name: string,
  email: string,
  sec: any[],
  doj: string
  
}